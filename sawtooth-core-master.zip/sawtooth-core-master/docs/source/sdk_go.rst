====================
Go SDK API Reference
====================

The Go SDK Reference is available only in the
`sawtooth-sdk-go source code <https://github.com/hyperledger/sawtooth-sdk-go>`__.

  .. tip::

     Use `godoc <https://godoc.org/golang.org/x/tools/cmd/godoc>`_  to extract
     and build the Go SDK reference.


.. Licensed under Creative Commons Attribution 4.0 International License
.. https://creativecommons.org/licenses/by/4.0/
