**********************
SDK and API References
**********************

Sawtooth SDK References:

.. include:: sdks.rst

.. toctree::
   :maxdepth: 2

   rest_api.rst

.. Licensed under Creative Commons Attribution 4.0 International License
.. https://creativecommons.org/licenses/by/4.0/
